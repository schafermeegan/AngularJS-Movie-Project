"use strict";
angular.module("MovieApp", ["ngRoute", ]);